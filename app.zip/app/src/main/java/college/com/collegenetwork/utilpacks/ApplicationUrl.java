package college.com.collegenetwork.utilpacks;

/**
 * Created by Krypto on 07-07-2017.
 */

public interface ApplicationUrl
{
    String BASE_URL = "http://192.168.33.1:888/cn/";

    String REGISTER = BASE_URL+"register.php";
    String LOGIN = BASE_URL+"login.php";
    String LISTFETCH = BASE_URL+"listfetch.php";
    String ENROLL = BASE_URL+"enroll.php";
    String REQUESTS = BASE_URL+"request.php";
    String MYSECTION = BASE_URL+"mysection.php";
    String MYAPPROVALS = BASE_URL+"approvals.php";
    String CHANGE_APPROVAL = BASE_URL+"prof_approve.php";
    String ADMIN_SUBJECTS = BASE_URL+"admin_subs.php";
    String ADMIN_PROFESSORS = BASE_URL+"admin_profs.php";
}
