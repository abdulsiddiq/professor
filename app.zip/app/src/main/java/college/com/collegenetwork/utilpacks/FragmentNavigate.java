package college.com.collegenetwork.utilpacks;

import android.support.v4.app.Fragment;

/**
 * Created by Krypto on 03-07-2017.
 */

public interface FragmentNavigate
{
    void showFragment( Fragment fragmentToShow, boolean addToBackStack);
}
