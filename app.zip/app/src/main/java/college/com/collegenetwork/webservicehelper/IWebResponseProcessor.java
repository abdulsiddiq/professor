package college.com.collegenetwork.webservicehelper;

/**
 * Created by Krypto on 20-06-2017.
 */

public interface IWebResponseProcessor
{
    void processResponse(Object obj,int status);
}
