package college.com.collegenetwork.dbhelper;

import android.database.Cursor;

/**
 * Created by sushantalone on 08/06/17.
 */

public interface IDBResultFetch {

    Cursor fillData( Cursor cursor );
}
